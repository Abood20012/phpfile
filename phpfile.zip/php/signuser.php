<?php
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$email = $_POST['email'];
$password = $_POST['password'];
$phone = $_POST['phone'];
$conn = new mysqli('localhost', 'root', '', 'login');
if($conn -> connect_error){
    die('connection failed :' .$conn->connect_error);
}else {
    $stmt=$conn->prepare("INSERT INTO signup-user ( f-name , l-name , e-mail ,password , phone-number) values(?,?,?,?,?)");
    $stmt -> bind_param("ssssi",$fname,$lname,$email,$password,$phone);
    $stmt -> execute();
    echo "login successfully";
    $stmt -> close();
    $conn ->close();
}
?>