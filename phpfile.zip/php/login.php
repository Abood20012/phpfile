<?php
$username = $_POST['username'];
$password = $_POST['password'];
$conn = new mysqli('localhost', 'root', '', 'login');
if($conn -> connect_error){
    die('connection failed :' .$conn->connect_error);
}else {
    $stmt=$conn->prepare("INSERT INTO login-1 ( mail , password) values(? , ?)");
    $stmt -> bind_param("ss",$username,$password);
    $firstname = $username;
    $lastname = $password;
    $stmt -> execute();
    echo "login successfully";
    $stmt -> close();
    $conn ->close();
}
?>